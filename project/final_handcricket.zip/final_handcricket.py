import tkinter as tk
from tkinter import font as tkfont
from tkinter import PhotoImage
from PIL import Image, ImageTk
import random, time
import os  # Add this import to check file existence

def rounded_rect(canvas, x1, y1, x2, y2, r=12, **kwargs):
    r = min(r, abs(x2 - x1) / 2, abs(y2 - y1) / 2)
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
        x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)

class HandCricketApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Hand Cricket")
        self.attributes("-fullscreen", True)
        self.bind("<Escape>", lambda e: self.quit())
        self.bind("<F11>", self._toggle_fullscreen)
        self.bg = "#ffffff"
        self.panel = "#f1f5f9"
        self.accent_green = "#16a34a"
        self.accent_blue = "#2563eb"
        self.accent_orange = "#d25e0c"
        self.box_colors = ["#ef4444", "#f59e0b", "#22c55e", "#3b82f6", "#8b5cf6", "#06b6d4"]
        self.timer_colors = ["#ff6b6b", "#ff9f1c", "#ffd166", "#6bcb77", "#4d96ff", "#9b5de5", "#c77dff", "#06b6d4"]
        self.configure(bg=self.bg)
        self.f_h1 = tkfont.Font(family="Segoe UI", size=28, weight="bold")
        self.f_h2 = tkfont.Font(family="Segoe UI", size=18, weight="bold")
        self.f_body = tkfont.Font(family="Segoe UI", size=12)
        self.f_big = tkfont.Font(family="Segoe UI", size=64, weight="bold")
        self._reset_state(full=True)
        self._build_frames()
        self._build_welcome()
        self._build_toss()
        self._build_game()
        self._build_gap()
        self._build_result()
        self.show_frame(self.welcome_frame)
        self.hand_images = self._load_hand_images()

    def _load_hand_images(self):
        """Load and resize hand images for player and computer."""
        images = {"player": [], "computer": []}
        for i in range(1, 8):  # Updated range to include 7
            player_path = f"c:/Users/pc/Desktop/project/images/player_{i}.png"
            computer_path = f"c:/Users/pc/Desktop/project/images/computer_{i}.png"
            if os.path.exists(player_path):
                img = Image.open(player_path).resize((369, 450))  # Resize to 369x450
                images["player"].append(ImageTk.PhotoImage(img))
            else:
                print(f"Error: Missing file {player_path}")
            if os.path.exists(computer_path):
                img = Image.open(computer_path).resize((369, 450))  # Resize to 369x450
                images["computer"].append(ImageTk.PhotoImage(img))
            else:
                print(f"Error: Missing file {computer_path}")
        return images

    def _toggle_fullscreen(self, event=None):
        self.attributes("-fullscreen", not self.attributes("-fullscreen"))

    def _reset_state(self, full=False):
        self.player_score = self.player_wickets = self.comp_score = self.comp_wickets = 0
        self.ball_results, self.innings1_balls, self.innings2_balls = [], [], []
        self.innings1_totals = self.innings2_totals = self.innings1_wkts = self.innings2_wkts = 0
        self.innings1_batter = None
        self.player_batting = True
        self.current_innings = 1
        self.target = None
        self.balls_played = 0
        self.timer_secs = 8
        self.timer_job = None
        self.timer_visible = False
        self.toss_pick = self.coin_result = self.toss_winner = None
        self.selector_map = {}
        self.tracker_items = []

    def _build_frames(self):
        self.container = tk.Frame(self, bg=self.bg)
        self.container.place(relwidth=1, relheight=1)
        self.welcome_frame = tk.Frame(self.container, bg=self.bg)
        self.toss_frame = tk.Frame(self.container, bg=self.bg)
        self.game_frame = tk.Frame(self.container, bg=self.bg)
        self.gap_frame = tk.Frame(self.container, bg=self.bg)
        self.result_frame = tk.Frame(self.container, bg=self.bg)
        for f in (self.welcome_frame, self.toss_frame, self.game_frame, self.gap_frame, self.result_frame):
            f.place(relwidth=1, relheight=1)

    def show_frame(self, frame):
        frame.tkraise()

    def _goto_toss(self, event=None):
        self._reset_state()
        self.draw_coin("?", 0)
        self.toss_msg.config(text="")
        try: self.toss_continue.pack_forget()
        except: pass
        self.show_frame(self.toss_frame)

    def _build_welcome(self):
        f = self.welcome_frame
        center = tk.Frame(f, bg=self.bg)
        center.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(center, text="Hand Cricket", font=self.f_h1, bg=self.bg, fg=self.accent_blue).pack(pady=(10,10))
        tk.Label(center, text="6 balls per innings • 8s timer • Fullscreen (Esc to exit)", font=self.f_body, bg=self.bg, fg="#475569").pack()
        btn_canvas = tk.Canvas(center, width=240, height=60, bg=self.bg, highlightthickness=0, bd=0)
        btn_canvas.pack(pady=24)
        rounded_rect(btn_canvas, 10, 10, 230, 50, r=24, fill="#15803d", outline="")
        btn_canvas.create_text(120, 30, text="Start Game", font=self.f_h2, fill="white")
        btn_canvas.bind("<Button-1>", self._goto_toss)
        btn_canvas.bind("<Enter>", lambda e: btn_canvas.config(cursor="hand2"))
        btn_canvas.bind("<Leave>", lambda e: btn_canvas.config(cursor=""))
        rules_canvas = tk.Canvas(center, width=120, height=40, bg=self.bg, highlightthickness=0, bd=0)
        rules_canvas.pack(pady=(0, 10))
        rounded_rect(rules_canvas, 8, 8, 112, 32, r=14, fill="#2563eb", outline="")
        rules_canvas.create_text(60, 20, text="Rules", font=self.f_body, fill="white")
        rules_canvas.bind("<Button-1>", lambda e: self._show_rules())
        rules_canvas.bind("<Enter>", lambda e: rules_canvas.config(cursor="hand2"))
        rules_canvas.bind("<Leave>", lambda e: rules_canvas.config(cursor=""))

    def _show_rules(self):
        rules_text = (
            "Hand Cricket Rules:\n\n"
            "• The game is played in two innings, each with 6 balls.\n"
            "• At the start, a toss decides who bats or bowls first.\n"
            "• On each ball, both player and computer pick a number (1-6).\n"
            "• If both pick the same number, it's a WICKET!\n"
            "• Otherwise, the batter scores runs equal to their chosen number.\n"
            "• After 6 balls or 1 wicket, innings switch.\n"
            "• The team with the higher score after both innings wins.\n\n"
            "Tips:\n• You have 8 seconds to pick a number each ball.\n• Press Esc to exit fullscreen at any time."
        )
        popup = tk.Toplevel(self)
        popup.title("Game Rules")
        popup.transient(self)
        popup.grab_set()
        popup.configure(bg="white")
        width, height = 600, 480
        self.update_idletasks()
        x = self.winfo_rootx() + (self.winfo_width() // 2) - (width // 2)
        y = self.winfo_rooty() + (self.winfo_height() // 2) - (height // 2)
        popup.geometry(f"{width}x{height}+{x}+{y}")
        popup.resizable(False, False)
        tk.Label(popup, text="Game Rules", font=self.f_h2, bg="white", fg=self.accent_blue).pack(pady=(20, 8), padx=16)
        tk.Label(popup, text=rules_text, font=self.f_body, bg="white", fg="#0f172a", justify="left", anchor="w", wraplength=560).pack(padx=24, pady=(0, 24), fill="both", expand=True)
        btn_canvas = tk.Canvas(popup, width=140, height=48, bg="white", highlightthickness=0, bd=0)
        btn_canvas.pack(pady=(0, 24))
        rounded_rect(btn_canvas, 6, 6, 134, 42, r=20, fill=self.accent_green, outline="#15803d")
        btn_canvas.create_text(70, 24, text="Close", font=self.f_h2, fill="white")
        btn_canvas.bind("<Button-1>", lambda e: popup.destroy())
        btn_canvas.bind("<Enter>", lambda e: btn_canvas.config(cursor="hand2"))
        btn_canvas.bind("<Leave>", lambda e: btn_canvas.config(cursor=""))

    def _build_toss(self):
        f = self.toss_frame
        for w in f.winfo_children(): w.destroy()
        f.configure(bg="#ADD8E6")
        self.create_label(f, "Toss", ("Arial Black", 28), "#ADD8E6", "#0b3d91").place(relx=0.5, y=60, anchor="center")
        self.coin_canvas = tk.Canvas(f, width=120, height=120, bg="#ADD8E6", highlightthickness=0, bd=0)
        self.coin_canvas.place(relx=0.5, y=200, anchor="center")
        self.coin_canvas.create_oval(10, 10, 110, 110, fill="gold", outline="orange", width=4)
        self.coin_canvas.create_text(60, 60, text="?", font=("Arial Black", 40), fill="brown")
        btn_frame = self.create_frame(f, "#ADD8E6")
        btn_frame.place(relx=0.5, y=350, anchor="center")
        heads_canvas = self.create_rounded_button(btn_frame, "Heads", lambda: self._start_coin("Heads"), "white", "#0b3d91", "#e0f2ff", "#0b3d91")
        heads_canvas.grid(row=0, column=0, padx=(0, 16))
        tails_canvas = self.create_rounded_button(btn_frame, "Tails", lambda: self._start_coin("Tails"), "white", "#0b3d91", "#e0f2ff", "#0b3d91")
        tails_canvas.grid(row=0, column=1, padx=(16, 0))
        self.toss_msg = self.create_label(f, "", self.f_h2, "#ADD8E6", "#0f172a")
        self.toss_msg.place(relx=0.5, y=410, anchor="center")

    def draw_coin(self, face, tilt):
        c = self.coin_canvas
        c.delete("all")
        c.create_oval(10, 10, 110, 110, fill="gold", outline="orange", width=4)
        if face == "Heads":
            c.create_text(60, 60, text="🧑", font=("Segoe UI Emoji", 40, "bold"), fill="#0b3d91")
            c.create_text(60, 100, text="HEADS", font=("Arial", 12, "bold"), fill="#0b3d91")
        elif face == "Tails":
            c.create_text(60, 60, text="🦊", font=("Segoe UI Emoji", 40, "bold"), fill="#0b3d91")
            c.create_text(60, 100, text="TAILS", font=("Arial", 12, "bold"), fill="#0b3d91")
        elif face == "?":
            c.create_text(60, 60, text="?", font=("Arial Black", 40), fill="brown")
        else:
            c.create_text(60, 60, text=face, font=("Arial", 22, "bold"), fill="#0b3d91")

    def _start_coin(self, pick):
        self.toss_pick = pick
        self.toss_msg.config(text="Flipping coin...", fg="#2563eb")
        self.flip_start = time.time()
        self.flip_duration = 1.0
        self._coin_anim()

    def _coin_anim(self):
        elapsed = time.time() - self.flip_start
        if elapsed < self.flip_duration:
            face = random.choice(["Heads", "Tails"])
            self.draw_coin(face, elapsed*10)
            self.after(80, self._coin_anim)
        else:
            self.coin_result = random.choice(["Heads", "Tails"])
            self.draw_coin(self.coin_result, 0)
            if self.coin_result == self.toss_pick:
                self.toss_winner = "Player"
            else:
                self.toss_winner = "Computer"
                comp_choice = random.choice(["Bat", "Bowl"])
                self.player_batting = (comp_choice == "Bowl")
            self.after(1500, self._show_toss_result_screen)

    def _show_toss_result_screen(self):
        self._build_toss_result()
        self.show_frame(self.toss_result_frame)

    def _build_toss_result(self):
        if hasattr(self, "toss_result_frame") and self.toss_result_frame.winfo_exists():
            self.toss_result_frame.destroy()
        self.toss_result_frame = tk.Frame(self.container, bg="#ADD8E6")
        self.toss_result_frame.place(relwidth=1, relheight=1)
        f = self.toss_result_frame
        if self.toss_winner == "Player":
            msg = "You won the toss!"
            submsg = "Press Continue to choose Bat or Bowl."
            color = self.accent_blue
        else:
            msg = "Computer won the toss!"
            comp_choice = "Bat" if self.player_batting else "Bowl"
            submsg = f"Computer chooses to {comp_choice} first."
            color = self.accent_blue
        tk.Label(f, text=msg, font=self.f_h1, bg="#ADD8E6", fg=color).pack(pady=(80,16))
        tk.Label(f, text=f"Coin Result: {self.coin_result}", font=self.f_h2, bg="#ADD8E6", fg=color).pack(pady=(0,8))
        tk.Label(f, text=submsg, font=self.f_body, bg="#ADD8E6", fg="#0f172a").pack(pady=(0,24))
        cont_canvas, _ = self._rounded_action_button(f, "Continue", self._after_toss_continue, self.accent_green, "white", "#22c55e", "white")
        cont_canvas.pack(pady=12)

    def _after_toss_continue(self):
        if self.toss_winner == "Player":
            self._show_bat_bowl_choice_screen()
        else:
            self._show_role_confirm_screen()

    def _show_bat_bowl_choice_screen(self):
        if hasattr(self, "batbowl_frame") and self.batbowl_frame.winfo_exists():
            self.batbowl_frame.destroy()
        self.batbowl_frame = tk.Frame(self.container, bg="#ADD8E6")
        self.batbowl_frame.place(relwidth=1, relheight=1)
        f = self.batbowl_frame
        tk.Label(f, text="Choose Bat or Bowl", font=self.f_h1, bg="#ADD8E6", fg=self.accent_blue).pack(pady=(80,24))
        btns = tk.Frame(f, bg="#ADD8E6")
        btns.pack(pady=16)
        bat_canvas = self.create_rounded_button(btns, "Bat First", lambda: self._bat_bowl_choice(True), self.accent_green, "white", "#22c55e", "white")
        bat_canvas.grid(row=0, column=0, padx=18)
        bowl_canvas = self.create_rounded_button(btns, "Bowl First", lambda: self._bat_bowl_choice(False), self.accent_blue, "white", "#3b82f6", "white")
        bowl_canvas.grid(row=0, column=1, padx=18)
        self.show_frame(self.batbowl_frame)

    def _rounded_action_button(self, master, text, command, bg, fg, activebg, activefg):
        btn_width, btn_height = 140, 48
        canvas = tk.Canvas(master, width=btn_width, height=btn_height, bg=master["bg"], highlightthickness=0, bd=0)
        rid = rounded_rect(canvas, 2, 2, btn_width-2, btn_height-2, r=22, fill=bg, outline="#b6c9d6")
        label = tk.Label(master, text=text, font=self.f_h2, bg=bg, fg=fg, bd=0, relief="flat", cursor="hand2")
        label.place(in_=canvas, relx=0.5, rely=0.5, anchor="center")
        def on_enter(e): canvas.itemconfig(rid, fill=activebg); label.config(bg=activebg, fg=activefg)
        def on_leave(e): canvas.itemconfig(rid, fill=bg); label.config(bg=bg, fg=fg)
        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)
        label.bind("<Button-1>", lambda e: command())
        return canvas, label

    def _bat_bowl_choice(self, bat_first):
        self.player_batting = bat_first
        self._show_role_confirm_screen()

    def _show_role_confirm_screen(self):
        if hasattr(self, "role_confirm_frame") and self.role_confirm_frame.winfo_exists():
            self.role_confirm_frame.destroy()
        self.role_confirm_frame = tk.Frame(self.container, bg="#ADD8E6")
        self.role_confirm_frame.place(relwidth=1, relheight=1)
        f = self.role_confirm_frame
        msg = "You are Batting First!" if self.player_batting else "You are Bowling First!"
        color = self.accent_green if self.player_batting else self.accent_blue
        tk.Label(f, text=msg, font=self.f_h1, bg="#ADD8E6", fg=color).pack(pady=(100,24))
        start_canvas, _ = self._rounded_action_button(f, "Start Game", self._start_game_after_confirm, self.accent_green, "white", "#22c55e", "white")
        start_canvas.pack(pady=16)
        self.show_frame(self.role_confirm_frame)

    def _start_game_after_confirm(self):
        self.show_frame(self.game_frame)
        self._setup_game_ui(first_innings=True, show_choice=False)

    def _build_game(self):
        f = self.game_frame
        top = tk.Frame(f, bg=self.panel, height=60)
        top.pack(fill="x", padx=10, pady=8)
        self.status_label = tk.Label(top, text="", bg=self.panel, font=self.f_body, fg="#0f172a")
        self.status_label.pack(side="left", padx=12)
        self.target_label = tk.Label(top, text="Target: —", bg=self.panel, font=self.f_body, fg="#0f172a")
        self.target_label.pack(side="right", padx=12)
        self.score_table1_frame = tk.Frame(f, bg="#f0fdf4", bd=2, relief="ridge", highlightbackground="#16a34a", highlightthickness=2)
        self.score_table1_frame.place(relx=0.5, y=60, anchor="n")
        self.score_table1_label = tk.Label(self.score_table1_frame, text="Batter: —", font=("Segoe UI", 16, "bold"), bg="#f0fdf4", fg="#15803d", width=14)
        self.score_table1_label.grid(row=0, column=0, padx=8, pady=2)
        self.score_table1_score = tk.Label(self.score_table1_frame, text="Score: 0", font=("Segoe UI", 16, "bold"), bg="#f0fdf4", fg="#22c55e", width=10)
        self.score_table1_score.grid(row=0, column=1, padx=8, pady=2)
        self.score_table2_frame = tk.Frame(f, bg="#f0f9ff", bd=2, relief="ridge", highlightbackground="#2563eb", highlightthickness=2)
        self.score_table2_frame.place(relx=0.5, y=120, anchor="n")
        self.score_table2_label = tk.Label(self.score_table2_frame, text="Batter: —", font=("Segoe UI", 16, "bold"), bg="#f0f9ff", fg="#1e40af", width=14)
        self.score_table2_label.grid(row=0, column=0, padx=8, pady=2)
        self.score_table2_score = tk.Label(self.score_table2_frame, text="Score: 0", font=("Segoe UI", 16, "bold"), bg="#f0f9ff", fg="#2563eb", width=10)
        self.score_table2_score.grid(row=0, column=1, padx=8, pady=2)
        self.score_table2_target = tk.Label(self.score_table2_frame, text="Target: —", font=("Segoe UI", 16, "bold"), bg="#f0f9ff", fg="#d25e0c", width=12)
        self.score_table2_target.grid(row=0, column=2, padx=8, pady=2)
        center = tk.Frame(f, bg=self.bg)
        center.pack(expand=True, fill="both", padx=12, pady=6)
        self.left_panel = tk.Frame(center, bg=self.bg, width=369, height=450)  # Set fixed width and height
        self.left_panel.place(relx=0.05, rely=0.5, anchor="w")  # Positioned at left middle
        tk.Label(self.left_panel, text="YOU", font=self.f_body, bg=self.bg, fg=self.accent_green).pack(pady=(8, 4))
        self.you_big = tk.Label(self.left_panel, image=None, bg=self.bg, width=369, height=450)  # Set fixed width and height
        self.you_big.pack()

        self.right_panel = tk.Frame(center, bg=self.bg, width=369, height=450)  # Set fixed width and height
        self.right_panel.place(relx=0.95, rely=0.5, anchor="e")  # Positioned at right middle
        tk.Label(self.right_panel, text="COMPUTER", font=self.f_body, bg=self.bg, fg=self.accent_blue).pack(pady=(8, 4))
        self.comp_big = tk.Label(self.right_panel, image=None, bg=self.bg, width=369, height=450)  # Set fixed width and height
        self.comp_big.pack()
        self.timer_col = tk.Frame(center, bg=self.bg)
        self.timer_col.place(relx=0.45, rely=0.32, relwidth=0.10, relheight=0.60)
        self.timer_canvas = tk.Canvas(self.timer_col, bg=self.bg, highlightthickness=0)
        self.timer_canvas.place(relx=0, rely=0, relwidth=1, relheight=1)
        bottom_area = tk.Frame(f, bg=self.bg)
        bottom_area.pack(side="bottom", fill="x", pady=12)
        self.tracker_canvas = tk.Canvas(bottom_area, bg=self.bg, highlightthickness=0, height=90)
        self.tracker_canvas.pack(side="top", pady=(2,6), fill="x")
        self.tracker_canvas.bind("<Configure>", lambda e: self._draw_tracker())
        self.selector_canvas = tk.Canvas(bottom_area, bg=self.bg, highlightthickness=0, height=120)
        self.selector_canvas.pack(side="top", pady=(2,10), fill="x")
        self.selector_canvas.bind("<Configure>", lambda e: self._draw_selectors())
        self.selector_canvas.bind("<Button-1>", self._on_selector_click)
        self.msg_label = tk.Label(f, text="", font=self.f_h2, bg=self.bg, fg="#0f172a")
        self.msg_label.pack(pady=(2,8))

    def create_rounded_button(self, master, text, command, bg, fg, activebg, activefg, width=140, height=48):
        canvas = tk.Canvas(master, width=width, height=height, bg=master["bg"], highlightthickness=0, bd=0)
        rid = rounded_rect(canvas, 2, 2, width-2, height-2, r=22, fill=bg, outline="#b6c9d6")
        label = tk.Label(master, text=text, font=self.f_h2, bg=bg, fg=fg, bd=0, relief="flat", cursor="hand2")
        label.place(in_=canvas, relx=0.5, rely=0.5, anchor="center")
        def on_enter(e): canvas.itemconfig(rid, fill=activebg); label.config(bg=activebg, fg=activefg)
        def on_leave(e): canvas.itemconfig(rid, fill=bg); label.config(bg=bg, fg=fg)
        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)
        label.bind("<Button-1>", lambda e: command())
        return canvas

    def create_label(self, master, text, font, bg, fg, **kwargs):
        return tk.Label(master, text=text, font=font, bg=bg, fg=fg, **kwargs)

    def create_frame(self, master, bg, **kwargs):
        return tk.Frame(master, bg=bg, **kwargs)

    def _draw_selectors(self):
        c = self.selector_canvas
        c.delete("all")
        self.selector_map.clear()
        W = c.winfo_width() or self.winfo_reqwidth() or 1000
        total_w = min(800, W - 200)
        btn_w, btn_h = 64, 38
        gap = max(10, (total_w - (btn_w)*6) / 5)
        start_x = (W - total_w) / 2 + btn_w/2
        y = 60
        for i in range(6):
            x = start_x + i*(btn_w + gap)
            shadow_y = y + 6
            # Draw shadow (optional)
            rounded_rect(c, x-btn_w/2, shadow_y-btn_h/2, x+btn_w/2, shadow_y+btn_h/2, r=btn_h/2, fill="#FFFFE8", outline="#bdbdbd", width=2)
            # Draw main pill
            pill = rounded_rect(c, x-btn_w/2, y-btn_h/2, x+btn_w/2, y+btn_h/2, r=btn_h/2, fill="#FFFFE8", outline="#707070", width=2)
            c.create_text(x, y, text=str(i+1), font=("Segoe UI", 18, "bold"), fill="#707070")
            c.addtag_withtag("selector", pill)
            self.selector_map[pill] = i+1

    def _draw_tracker(self):
        c = self.tracker_canvas
        c.delete("all")
        self.tracker_items.clear()
        W = c.winfo_width() or 1000
        box_size, gap = 60, 24
        total_w = 6 * box_size + 5 * gap
        start_x = (W - total_w) / 2
        y1, y2 = 5, 65
        for i in range(6):
            x1 = start_x + i * (box_size + gap)
            x2 = x1 + box_size
            rect = rounded_rect(c, x1, y1, x2, y2, r=18, fill="#F7F7E8", outline="#1F3A40", width=4)
            txt = c.create_text((x1+x2)/2, (y1+y2)/2, text="", font=("Segoe UI", 20, "bold"), fill="#C0C000")
            self.tracker_items.append((rect, txt))

    def _on_selector_click(self, event):
        items = self.selector_canvas.find_overlapping(event.x, event.y, event.x, event.y)
        for it in items:
            if it in self.selector_map:
                val = self.selector_map[it]
                if self.timer_visible:
                    self._player_pick(val)
                return

    def _setup_game_ui(self, first_innings=True, show_choice=False):
        self.ball_results = []
        self.balls_played = self.player_score = self.player_wickets = self.comp_score = self.comp_wickets = 0
        # Set player_7.png and computer_7.png images at the start of the innings
        self.you_big.config(image=self.hand_images["player"][6])  # Display player_7.png
        self.comp_big.config(image=self.hand_images["computer"][6])  # Display computer_7.png
        self.msg_label.config(text="")  # Clear any previous messages
        self._draw_tracker()
        self._draw_selectors()
        self._update_top_labels()
        if show_choice:
            choice_win = tk.Toplevel(self)
            choice_win.title("Choose")
            choice_win.transient(self)
            choice_win.grab_set()
            tk.Label(choice_win, text="You won toss — Choose Bat or Bowl", font=self.f_body).pack(padx=12, pady=8)
            frame = tk.Frame(choice_win)
            frame.pack(pady=6)
            tk.Button(frame, text="Bat First", bg=self.accent_green, fg="white", command=lambda: (self._choose_and_close(choice_win, True))).grid(row=0, column=0, padx=6)
            tk.Button(frame, text="Bowl First", bg=self.accent_blue, fg="white", command=lambda: (self._choose_and_close(choice_win, False))).grid(row=0, column=1, padx=6)
        else:
            self.after(300, self.prepare_next_ball)

    def _choose_and_close(self, win, bat_first):
        self.player_batting = bat_first
        win.destroy()
        self.prepare_next_ball()

    def _update_top_labels(self):
        inning_text = "1st Innings" if self.current_innings == 1 else "2nd Innings"
        role_text = "You Batting" if self.player_batting else "You Bowling"
        self.status_label.config(text=f"{inning_text} • {role_text} • Balls: {self.balls_played}/6")
        self.target_label.config(text=f"Target: {self.target if self.target else '—'}")
        self._update_score_table()

    def _update_score_table(self):
        if self.current_innings == 1:
            self.score_table1_frame.lift()
            self.score_table1_frame.place(relx=0.5, y=60, anchor="n")  # Keep the 1st innings box as is
            self.score_table2_frame.place_forget()
            batter = "You" if self.player_batting else "Computer"
            score = self.player_score if self.player_batting else self.comp_score
            self.score_table1_label.config(text=f"Batter: {batter}")
            self.score_table1_score.config(text=f"Score: {score}")
        else:
            self.score_table2_frame.lift()
            self.score_table2_frame.place(relx=0.5, y=40, anchor="n")  # Move the 2nd innings box higher
            self.score_table1_frame.place_forget()
            batter = "You" if self.player_batting else "Computer"
            score = self.player_score if self.player_batting else self.comp_score
            self.score_table2_label.config(text=f"Batter: {batter}")
            self.score_table2_score.config(text=f"Score: {score}")
            self.score_table2_target.config(text=f"Target: {self.target if self.target else '—'}")

    def prepare_next_ball(self):
        if self.current_innings == 2 and self.target is not None:
            if (self.player_batting and self.player_score >= self.target) or (not self.player_batting and self.comp_score >= self.target):
                self.finish_match()
                return
        if (self.player_batting and self.player_wickets == 1) or (not self.player_batting and self.comp_wickets == 1):
            self._end_innings_or_match()
            return
        self.timer_visible = True
        self.timer_secs = 8
        self._draw_timer(0, self.timer_colors[0], 8)
        self._tick_timer()

    def _tick_timer(self):
        if not self.timer_visible: return
        elapsed = 8 - self.timer_secs
        degrees = int((elapsed / 8.0) * 360)
        color = self.timer_colors[elapsed % len(self.timer_colors)]
        self._draw_timer(degrees, color, self.timer_secs)
        if self.timer_secs > 0:
            self.timer_secs -= 1
            self.timer_job = self.after(1000, self._tick_timer)
        else:
            self._draw_timer(360, self.timer_colors[-1], 0)
            self.after(300, lambda: self._player_pick(random.randint(1,6), timed_out=True))

    def _draw_timer(self, degrees, color, secs_left):
        c = self.timer_canvas
        c.delete("all")
        W = c.winfo_width() or 160
        H = c.winfo_height() or 160
        size = min(W, H) - 10
        cx, cy = W/2, H/2
        r = size/2
        for i in (3,2,1):
            c.create_oval(cx-r-i*4, cy-r-i*4, cx+r+i*4, cy+r+i*4, outline=color, width=1, stipple="gray12")
        c.create_oval(cx-r, cy-r, cx+r, cy+r, outline="#d1d5db", width=12)
        if degrees > 0:
            c.create_arc(cx-r, cy-r, cx+r, cy+r, start=90, extent=-degrees, fill=color, outline=color)
        inner = r*0.6
        c.create_oval(cx-inner, cy-inner, cx+inner, cy+inner, fill=self.bg, outline=self.bg)
        c.create_text(cx, cy, text=f"{secs_left}s", font=("Segoe UI", 16, "bold"), fill="#0f172a")

    def _hide_timer(self):
        self.timer_visible = False
        if self.timer_job:
            try: self.after_cancel(self.timer_job)
            except: pass
            self.timer_job = None
        self.timer_canvas.delete("all")

    def _player_pick(self, value, timed_out=False):
        if not self.timer_visible: return
        self._hide_timer()
        comp_val = random.randint(1, 6)

        # Display the run scored or WICKET message temporarily
        def show_run_message(run_value, color):
            # Create labels for the run value and "RUNS"
            run_label = tk.Label(self.game_frame, text=str(run_value), font=("Segoe UI", 48, "bold"), bg=self.bg, fg=color)
            runs_text_label = tk.Label(self.game_frame, text="RUNS", font=("Segoe UI", 24, "bold"), bg=self.bg, fg=color)

            # Position the labels
            run_label.place(relx=0.5, rely=0.2, anchor="center")  # Run value at the top center
            runs_text_label.place(relx=0.5, rely=0.3, anchor="center")  # "RUNS" below the run value

            # Animate the run value (increase size temporarily)
            def animate_run_label(step=0):
                if step < 5:  # Increase size
                    run_label.config(font=("Segoe UI", 48 + step * 4, "bold"))
                    self.after(50, animate_run_label, step + 1)
                elif step < 10:  # Decrease size back to normal
                    run_label.config(font=("Segoe UI", 68 - (step - 5) * 4, "bold"))
                    self.after(50, animate_run_label, step + 1)
                else:  # Remove labels after animation
                    run_label.destroy()
                    runs_text_label.destroy()

            animate_run_label()

        # Update player's and computer's images immediately
        self.you_big.config(image=self.hand_images["player"][value - 1])
        self.comp_big.config(image=self.hand_images["computer"][comp_val - 1])

        if self.player_batting:
            if value == comp_val:
                self.player_wickets += 1
                self._add_ball("W", for_player=True)
                show_run_message("WICKET", "#ef4444")  # Display WICKET message
                self.msg_label.config(text=f"WICKET! You matched {comp_val}")
                self.after(1200, self._end_innings_or_match)
                return
            else:
                self.player_score += value
                self._add_ball(str(value), for_player=True)
                show_run_message(value, "#16a34a")  # Display runs scored
                self.msg_label.config(text=f"You scored {value} (Comp {comp_val})")
            if self.balls_played >= 6:
                self.after(1200, self._end_innings_or_match)
            else:
                if self.current_innings == 2 and self.target is not None and self.player_score >= self.target:
                    self.after(1200, self.finish_match)
                    return
                self.after(1200, self.prepare_next_ball)
        else:
            if value == comp_val:
                self.comp_wickets += 1
                self._add_ball("W", for_player=False)
                show_run_message("WICKET", "#ef4444")  # Display WICKET message
                self.msg_label.config(text=f"WICKET! Computer matched {comp_val}")
                self.after(1200, self._end_innings_or_match)
                return
            else:
                self.comp_score += comp_val
                self._add_ball(str(comp_val), for_player=False)
                show_run_message(comp_val, "#2563eb")  # Display runs scored
                self.msg_label.config(text=f"Computer scored {comp_val} (Your bowl: {value})")
            if self.balls_played >= 6:
                self.after(1200, self._end_innings_or_match)
            else:
                if self.current_innings == 2 and self.target is not None and self.comp_score >= self.target:
                    self.after(1200, self.finish_match)
                    return
                self.after(1200, self.prepare_next_ball)

    def _add_ball(self, val, for_player=True):
        idx = len(self.ball_results)
        if idx >= 6: return
        self.ball_results.append(val)
        rect, txt = self.tracker_items[idx]
        if val == "W":
            self.tracker_canvas.itemconfig(rect, fill="#F7F7E8", outline="#1F3A40", width=4)
            self.tracker_canvas.itemconfig(txt, text="W", fill="#1F3A40")
        else:
            self.tracker_canvas.itemconfig(rect, fill="#F7F7E8", outline="#C0C000", width=4)
            self.tracker_canvas.itemconfig(txt, text=val, fill="#C0C000")
        self.balls_played = len(self.ball_results)
        self._update_top_labels()

    def _end_innings_or_match(self):
        if self.current_innings == 1:
            self.innings1_balls = self.ball_results[:]
            if self.player_batting:
                self.innings1_totals = self.player_score
                self.innings1_wkts = self.player_wickets
                self.innings1_batter = "You"
            else:
                self.innings1_totals = self.comp_score
                self.innings1_wkts = self.comp_wickets
                self.innings1_batter = "Computer"
            self.target = self.innings1_totals + 1
            self.gap_batter_label.config(text=f"Batter: {self.innings1_batter}")
            self.gap_score_label.config(text=f"Score: {self.innings1_totals} / {self.innings1_wkts}")
            self.gap_target_label.config(text=f"Target: {self.target}")
            self.show_frame(self.gap_frame)
        else:
            self.innings2_balls = self.ball_results[:]
            if self.player_batting:
                self.innings2_totals = self.player_score
                self.innings2_wkts = self.player_wickets
            else:
                self.innings2_totals = self.comp_score
                self.innings2_wkts = self.comp_wickets
            self.finish_match()

    def _start_second_innings(self):
        self.current_innings = 2
        self.player_batting = not self.player_batting
        self.ball_results = []
        self.balls_played = 0
        if self.player_batting:
            self.player_score = self.player_wickets = 0
        else:
            self.comp_score = self.comp_wickets = 0
        for rect, txt in self.tracker_items:
            self.tracker_canvas.itemconfig(txt, text="")
        self.you_big.config(text="?")
        self.comp_big.config(text="?")
        self.msg_label.config(text="")
        self.show_frame(self.game_frame)
        self._update_top_labels()
        self.after(400, self.prepare_next_ball)

    def finish_match(self):
        inn1_bat = self.innings1_batter or ("You" if self.innings1_totals else "You")
        you_total = comp_total = you_wkts = comp_wkts = 0
        if self.innings1_batter == "You":
            you_total = self.innings1_totals
            you_wkts  = self.innings1_wkts
            comp_total = self.innings2_totals
            comp_wkts  = self.innings2_wkts
        else:
            comp_total = self.innings1_totals
            comp_wkts  = self.innings1_wkts
            you_total = self.innings2_totals
            you_wkts  = self.innings2_wkts
        if self.current_innings == 2:
            if self.player_batting:
                you_total = max(you_total, self.player_score)
                you_wkts = self.player_wickets
            else:
                comp_total = max(comp_total, self.comp_score)
                comp_wkts = self.comp_wickets
        if self.innings1_totals == 0 and self.innings2_totals == 0:
            you_total = self.player_score
            comp_total = self.comp_score
            you_wkts = self.player_wickets
            comp_wkts = self.comp_wickets
        if you_total > comp_total:
            title = "🎉 You Win!"; clr = self.accent_green
        elif comp_total > you_total:
            title = "💻 Computer Wins!"; clr = self.accent_blue
        else:
            title = "🤝 Match Tied!"; clr = self.accent_orange
        self._populate_result(you_total, you_wkts, comp_total, comp_wkts, title, clr)
        self.show_frame(self.result_frame)

    def _populate_result(self, you_total, you_wkts, comp_total, comp_wkts, title, color):
        for w in self.result_frame.winfo_children(): w.destroy()
        tk.Label(self.result_frame, text=title, font=self.f_h1, bg=self.bg, fg=color).pack(pady=(40,8))
        summary = f"You: {you_total} / {you_wkts}   •   Computer: {comp_total} / {comp_wkts}   •   Target: {self.target if self.target else '—'}"
        tk.Label(self.result_frame, text=summary, font=self.f_h2, bg=self.bg, fg="#0f172a").pack(pady=(6,18))
        table = tk.Frame(self.result_frame, bg=self.bg)
        table.pack(pady=(12, 8))
        tk.Label(table, text="Summary", font=self.f_h2, bg=self.bg, fg=color).grid(row=0, column=0, columnspan=3, pady=(0, 6))
        tk.Label(table, text="Team", font=self.f_body, bg=self.bg, fg="#0f172a", width=12).grid(row=1, column=0)
        tk.Label(table, text="Score", font=self.f_body, bg=self.bg, fg="#0f172a", width=8).grid(row=1, column=1)
        tk.Label(table, text="Wickets", font=self.f_body, bg=self.bg, fg="#0f172a", width=8).grid(row=1, column=2)
        tk.Label(table, text="You", font=self.f_body, bg=self.bg, fg="#15803d").grid(row=2, column=0)
        tk.Label(table, text=str(you_total), font=self.f_body, bg=self.bg, fg="#15803d").grid(row=2, column=1)
        tk.Label(table, text=str(you_wkts), font=self.f_body, bg=self.bg, fg="#15803d").grid(row=2, column=2)
        tk.Label(table, text="Computer", font=self.f_body, bg=self.bg, fg="#2563eb").grid(row=3, column=0)
        tk.Label(table, text=str(comp_total), font=self.f_body, bg=self.bg, fg="#25603d").grid(row=3, column=1)
        tk.Label(table, text=str(comp_wkts), font=self.f_body, bg=self.bg, fg="#25603d").grid(row=3, column=2)
        btns = tk.Frame(self.result_frame, bg=self.bg)
        btns.pack(pady=16)
        play_canvas, _ = self._rounded_action_button(btns, "Play Again", self._goto_toss, self.accent_green, "white", "#22c55e", "white")
        play_canvas.grid(row=0, column=0, padx=8)
        exit_canvas, _ = self._rounded_action_button(btns, "Exit", self.quit, self.accent_orange, "white", "#f59e0b", "white")
        exit_canvas.grid(row=0, column=1, padx=8)

    def _build_gap(self):
        f = self.gap_frame
        table = self.create_frame(f, self.bg, bd=2, relief="ridge")
        table.pack(pady=(60, 8))
        self.create_label(table, "First Innings Summary", self.f_h2, self.bg, self.accent_orange).grid(row=0, column=0, columnspan=2, pady=(0, 6))
        self.gap_batter_label = self.create_label(table, "Batter: —", ("Segoe UI", 16, "bold"), self.bg, "#0f172a", width=16)
        self.gap_batter_label.grid(row=1, column=0, padx=8, pady=2)
        self.gap_score_label = self.create_label(table, "Score: —", ("Segoe UI", 16, "bold"), self.bg, "#16a34a", width=12)
        self.gap_score_label.grid(row=1, column=1, padx=8, pady=2)
        self.gap_target_label = self.create_label(table, "Target: —", ("Segoe UI", 16, "bold"), self.bg, "#d25e0c", width=28)
        self.gap_target_label.grid(row=2, column=0, columnspan=2, padx=8, pady=2)
        btn_canvas = self.create_rounded_button(f, "Continue", self._start_second_innings, "#16a34a", "white", "#22c55e", "white", width=180, height=54)
        btn_canvas.pack(pady=12)

    def _build_result(self):
        if hasattr(self, "result_frame") and self.result_frame.winfo_exists():
            for w in self.result_frame.winfo_children(): w.destroy()
        f = self.result_frame
        tk.Label(f, text="", bg=self.bg).pack()

if __name__ == "__main__":
    app = HandCricketApp()
    app.mainloop()